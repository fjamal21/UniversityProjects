package com.fjamal.data.structure.project;

import java.util.concurrent.ConcurrentHashMap;

/**
 * A simple timer class to measure the performance of code.
 * 
 * @author Ferhan Jamal
 *
 */
public class SimpleTimer {

    public static ConcurrentHashMap<Long, Long> histogram = new ConcurrentHashMap<Long, Long>();

    /**
     * Creates an instance of the timer and starts it running.
     */
    public static SimpleTimer getInstance() {
	return new SimpleTimer();
    }

    private long m_end = -1;
    private long m_interval = -1;
    private final long m_start;

    private SimpleTimer() {
	m_start = m_interval = currentTime();
    }

    /**
     * Returns in milliseconds the amount of time that has elapsed since the
     * timer was created.
     */
    public long getDuration() {
	long result = 0;

	final long startTime = m_start;
	final long endTime = isTimerRunning() ? currentTime() : m_end;

	result = nanoToMilliseconds(endTime - startTime);

	boolean done = false;
	while (!done) {
	    Long oldValue = histogram.putIfAbsent(result, 1L);
	    if (oldValue != null) {
		done = histogram.replace(result, oldValue, oldValue + 1);
	    } else {
		done = true;
	    }
	}

	return result;
    }

    /**
     * Returns in milliseconds the amount of time that has elapsed since the
     * last invocation of this same method.
     * 
     * @return
     */
    public long getInterval() {
	long result = 0;

	final long startTime = m_interval;
	final long endTime;

	if (isTimerRunning()) {
	    endTime = m_interval = currentTime();
	} else {
	    endTime = m_end;
	}

	result = nanoToMilliseconds(endTime - startTime);

	return result;
    }

    /**
     * Stops the timer from advancing.
     */
    public void stop() {
	if (isTimerRunning()) {
	    m_end = currentTime();
	}
    }

    private long currentTime() {
	return System.nanoTime();
    }

    private boolean isTimerRunning() {
	return (m_end <= 0);
    }

    private long nanoToMilliseconds(final long nanoseconds) {
	return nanoseconds / 1000000L;
    }

    public static void clearMap() {
	histogram.clear();
    }
}
