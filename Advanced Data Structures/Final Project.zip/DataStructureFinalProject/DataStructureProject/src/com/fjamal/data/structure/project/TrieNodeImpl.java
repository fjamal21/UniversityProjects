package com.fjamal.data.structure.project;

public class TrieNodeImpl {

    //root node
    private TrieNode r;

    public TrieNodeImpl() {
	r = new TrieNode();
    }

    /**
     * Find the frequencies basis on string.
     * 
     * @param word
     * @return
     */
    public int find(String word) {
	return r.getFrequencyOfString(word);
    }

    /**
     * Insert word and its frequencies to TRIE.
     * 
     * @param word
     * @param freq
     */
    public void insert(String word, int freq) {
	r.insert(word, freq);
    }

    public String toString() {
	return r.toString();
    }
}
