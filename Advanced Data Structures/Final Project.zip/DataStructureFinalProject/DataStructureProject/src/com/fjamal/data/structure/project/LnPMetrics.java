package com.fjamal.data.structure.project;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

/**
 * A simple class to measure the performance of various DataStructures.
 * 
 * @author Ferhan Jamal
 * 
 */
public class LnPMetrics {

    private Map<Long, Long> histogram;

    private long totalNumOfCall;
    private long avgLatency;
    private long nintyFifthPercentile;
    private long nintyNinePercentile;
    private long minTime;
    private long maxTime;
    private long totalTime;

    public LnPMetrics(Map<Long, Long> histogram) {
	this.histogram = histogram;

	calculateLnpMetrics();
    }

    /**
     * Calculate all LnP metrics
     * 
     */
    private void calculateLnpMetrics() {
	Long totalLatency = 0L;

	// Calculate total number of calls
	for (Long latency : histogram.keySet()) {
	    totalLatency += latency * histogram.get(latency);
	    totalNumOfCall += histogram.get(latency);
	}

	// Calculate avrage query time
	if (totalNumOfCall != 0) {
	    avgLatency = totalLatency / totalNumOfCall;
	}

	double nintyFifthpercentile = (double) totalNumOfCall * 0.95D;
	double nintyNinthpercentile = (double) totalNumOfCall * 0.99D;

	Long sumOfCount = 0L;

	List<Long> latencyList = new ArrayList<Long>(histogram.keySet());
	Collections.sort(latencyList);

	// Get min and max latency
	minTime = latencyList.get(0);
	maxTime = latencyList.get(latencyList.size() - 1);

	boolean hasNintyFifth = false;
	long totalSum = 0L;

	// Calculate 95 percentile and 99 percentile latency 
	for (Long latency : latencyList) {
	    sumOfCount += histogram.get(latency);

	    if (sumOfCount >= nintyFifthpercentile && !hasNintyFifth) {
		nintyFifthPercentile = latency;
		hasNintyFifth = true;
	    }
	    if (sumOfCount >= nintyNinthpercentile) {
		nintyNinePercentile = latency;
		break;
	    }
	}

	// total time
	for (Long latency : latencyList) {
	    totalSum += latency;
	}
	totalTime = totalSum;
    }

    public Map<Long, Long> getHistogram() {
	return histogram;
    }

    public long getTotalNumOfCall() {
	return totalNumOfCall;
    }

    public long getAvgLatency() {
	return avgLatency;
    }

    public long getNintyFifthPercentile() {
	return nintyFifthPercentile;
    }

    public long getNintyNinePercentile() {
	return nintyNinePercentile;
    }

    public long getMinTime() {
	return minTime;
    }

    public long getMaxTime() {
	return maxTime;
    }

    public long getTotalTime() {
	return totalTime;
    }

    @Override
    public String toString() {
	return "\nTotal number of calls: " + totalNumOfCall + "\nAverage Query Time: " + avgLatency + " ms"
		+ "\n95th percentile: " + nintyFifthPercentile + " ms" + "\n99th percentile: " + nintyNinePercentile
		+ " ms" + "\nMax query time: " + maxTime + " ms" + "\nMinimum query time: " + minTime + " ms"
		+ "\nTotal time: " + totalTime + " ms";
    }
}
