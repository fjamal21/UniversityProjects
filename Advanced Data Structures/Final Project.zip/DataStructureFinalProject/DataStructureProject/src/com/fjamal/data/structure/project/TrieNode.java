package com.fjamal.data.structure.project;

public class TrieNode {

    // make child nodes
    private TrieNode[] c;
    // flag for end of word
    private boolean flag = false;
    // stores frequency if flag is set
    private int frequency;

    public TrieNode() {
	c = new TrieNode[58];
    }

    /**
     * Below method is use to insert the word and its frequency to trie.
     * 
     * @param word
     * @param frequency
     */
    protected void insert(String word, int frequency) {
	int val = word.charAt(0) - 65;

	if (c[val] == null) {
	    c[val] = new TrieNode();
	}

	if (word.length() > 1) {
	    c[val].insert(word.substring(1), frequency);
	} else {
	    c[val].flag = true;
	    c[val].frequency = frequency;
	}
    }

    /**
     * Below method is use to lookup the frequencies basis on String.
     * 
     * @param word
     * @return
     */
    public int getFrequencyOfString(String word) {
	int val = word.charAt(0) - 65;
	if (val < 0 || val >= c.length || c[val] == null)
	    return -1;

	if (word.length() > 1) {
	    return c[val].getFrequencyOfString(word.substring(1));
	} else if (c[val].flag == true && word.length() == 1) {
	    return c[val].frequency;
	} else {
	    return -1;
	}
    }

    public String toString() {
	return c.toString();
    }
}
