package com.fjamal.data.structure.project;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 * @author Ferhan Jamal
 * 
 */
public class DataStructureProject {

    private static final Random RANDOM = new Random();
    private static int length = 6; // string length
    private static final String CHARACTERS = "abcdefghijklmnopqrstuvwxyz";
    private static String location = "C:/DataStructureProject/words.txt";
    private static int numberOfStrings = 6000000; // number of strings in a file
    private static int numberOfSearches = 1000000; // total number of random searches to be performed

    public static void main(String[] args) {

	readInputs(args);

	System.out.println("################################################");
	System.out.println("Generating file with below parameters:");
	System.out.println("File Location: " + location);
	System.out.println("Number of Strings you want to generate: " + numberOfStrings);
	System.out.println("Length of each strings: " + length);
	System.out.println("Number of random Searches you want to do: " + numberOfSearches);
	System.out.println("################################################");

	FileWriter fileWriter = null;
	BufferedWriter writer = null;
	try {

	    File newTextFile = new File(location);
	    File parent = newTextFile.getParentFile();
	    if (!parent.exists() && !parent.mkdirs()) {
		throw new IllegalStateException("Couldn't create dir: " + parent);
	    } else {
		System.out.println("Created new file: " + location);
	    }

	    fileWriter = new FileWriter(newTextFile, false);
	    writer = new BufferedWriter(fileWriter);

	    int i = 0;
	    while (i < numberOfStrings) {
		String content = generateString();
		writer.write(content);
		writer.newLine();
		i++;
	    }
	    writer.close();

	    System.out.println("File has been generated. Please verify the file at the desired location.");
	} catch (IOException ex) {
	    ex.printStackTrace();
	} finally {
	    try {
		writer.close();
	    } catch (IOException ex) {
		ex.printStackTrace();
	    }
	}

	// now starting various performance test
	hashMapPerformanceTest();
	treeMapPerformanceTest();
	linkedHashMapPerformanceTest();
	triePerformanceTest();
    }

    /**
     * Below method is use for TRIE performance test.
     */
    private static void triePerformanceTest() {

	//reading file line by line using BufferedReader       
	FileInputStream fis = null;
	BufferedReader reader = null;

	TrieNodeImpl trie = new TrieNodeImpl();

	try {
	    // we will load all the word frequency list in a HashMap
	    fis = new FileInputStream(location);
	    reader = new BufferedReader(new InputStreamReader(fis));

	    System.out.println("############################################################");
	    System.out.println("Started TRIE insertion performance test");

	    Runtime rt = Runtime.getRuntime();
	    long m0 = rt.totalMemory() - rt.freeMemory(); //used memory

	    String line = reader.readLine();
	    while (line != null && !line.isEmpty()) {
		// split the string on whitespace
		String[] splittedString = line.split("\\s+");
		String split1 = splittedString[0].toLowerCase().trim();
		Integer split2 = Integer.parseInt(splittedString[1].trim());
		SimpleTimer timer = SimpleTimer.getInstance();
		// now put it in HashMap as key value  pair
		trie.insert(split1, split2);
		timer.getDuration();
		line = reader.readLine();
	    }
	    long m1 = rt.totalMemory() - rt.freeMemory();
	    Map<Long, Long> insertHistogram = SimpleTimer.histogram;
	    LnPMetrics insertionMetrics = new LnPMetrics(insertHistogram);
	    System.out.println(insertionMetrics);
	    System.out.println("Memory: Size in Memory after insertion (bytes): " + (m1 - m0));
	    System.out.println();
	    SimpleTimer.clearMap();

	    System.out.println("Started TRIE Read performance test");
	    // now search a string
	    int counter = 0;
	    for (int i = 0; i < numberOfSearches; i++) {
		String ranndomString = generateRandomString();
		SimpleTimer readTimer = SimpleTimer.getInstance();
		if (trie.find(ranndomString) != -1) {
		    counter++;
		}
		readTimer.getDuration();
	    }
	    Map<Long, Long> readHistogram = SimpleTimer.histogram;
	    LnPMetrics readMetrics = new LnPMetrics(readHistogram);

	    System.out.println(readMetrics);
	    System.out.println("Total Number of hits: " + counter);
	    SimpleTimer.clearMap();

	} catch (FileNotFoundException ex) {
	    ex.printStackTrace();
	} catch (IOException ex) {
	    ex.printStackTrace();
	} finally {
	    try {
		reader.close();
		fis.close();
	    } catch (IOException ex) {
		ex.printStackTrace();
	    }
	}

    }

    /**
     * Below method is use for HashMap performance test
     */
    private static void hashMapPerformanceTest() {

	//reading file line by line using BufferedReader       
	FileInputStream fis = null;
	BufferedReader reader = null;

	Map<String, Integer> wordFrequencies = new HashMap<String, Integer>();

	try {
	    // we will load all the word frequency list in a HashMap
	    fis = new FileInputStream(location);
	    reader = new BufferedReader(new InputStreamReader(fis));

	    System.out.println("############################################################");
	    System.out.println("Started HashMap insertion performance test");

	    Runtime rt = Runtime.getRuntime();
	    long m0 = rt.totalMemory() - rt.freeMemory(); //used memory

	    String line = reader.readLine();
	    while (line != null && !line.isEmpty()) {
		// split the string on whitespace
		String[] splittedString = line.split("\\s+");
		String split1 = splittedString[0].toLowerCase().trim();
		Integer split2 = Integer.parseInt(splittedString[1].trim());
		SimpleTimer timer = SimpleTimer.getInstance();
		// now put it in HashMap as key value  pair
		wordFrequencies.put(split1, split2);
		timer.getDuration();
		line = reader.readLine();
	    }

	    long m1 = rt.totalMemory() - rt.freeMemory();
	    Map<Long, Long> insertHistogram = SimpleTimer.histogram;
	    LnPMetrics insertionMetrics = new LnPMetrics(insertHistogram);
	    System.out.println(insertionMetrics);
	    System.out.println("Memory: Size in Memory after insertion (bytes): " + (m1 - m0));
	    System.out.println();
	    SimpleTimer.clearMap();

	    System.out.println("Started HashMap Read performance test");
	    // now search a string
	    int counter = 0;
	    for (int i = 0; i < numberOfSearches; i++) {
		String ranndomString = generateRandomString();
		SimpleTimer readTimer = SimpleTimer.getInstance();
		if (wordFrequencies.get(ranndomString) != null) {
		    counter++;
		}
		readTimer.getDuration();
	    }
	    Map<Long, Long> readHistogram = SimpleTimer.histogram;
	    LnPMetrics readMetrics = new LnPMetrics(readHistogram);

	    System.out.println(readMetrics);
	    System.out.println("Total Number of hits: " + counter);
	    SimpleTimer.clearMap();

	} catch (FileNotFoundException ex) {
	    ex.printStackTrace();
	} catch (IOException ex) {
	    ex.printStackTrace();
	} finally {
	    try {
		reader.close();
		fis.close();
	    } catch (IOException ex) {
		ex.printStackTrace();
	    }
	}
    }

    /**
     * Below method is for testing LinkedHashMap performance testing.
     */
    private static void linkedHashMapPerformanceTest() {

	//reading file line by line using BufferedReader       
	FileInputStream fis = null;
	BufferedReader reader = null;

	Map<String, Integer> wordFrequencies = new LinkedHashMap<String, Integer>();

	try {
	    // we will load all the word frequency list in a LinkedHashMap
	    fis = new FileInputStream(location);
	    reader = new BufferedReader(new InputStreamReader(fis));

	    System.out.println("############################################################");
	    System.out.println("Started LinkedHashMap insertion performance test");

	    Runtime rt = Runtime.getRuntime();
	    long m0 = rt.totalMemory() - rt.freeMemory(); //used memory
	    String line = reader.readLine();
	    while (line != null && !line.isEmpty()) {
		// split the string on whitespace
		String[] splittedString = line.split("\\s+");
		String split1 = splittedString[0].toLowerCase().trim();
		Integer split2 = Integer.parseInt(splittedString[1].trim());
		SimpleTimer timer = SimpleTimer.getInstance();
		// now put it in LinkedHashMap as key value  pair
		wordFrequencies.put(split1, split2);
		timer.getDuration();
		line = reader.readLine();
	    }
	    long m1 = rt.totalMemory() - rt.freeMemory();
	    Map<Long, Long> insertHistogram = SimpleTimer.histogram;
	    LnPMetrics insertionMetrics = new LnPMetrics(insertHistogram);
	    System.out.println(insertionMetrics);
	    System.out.println("Memory: Size in Memory after insertion (bytes): " + (m1 - m0));
	    System.out.println();
	    SimpleTimer.clearMap();

	    System.out.println("Started LinkedHashMap Read performance test");
	    // now search a string
	    int counter = 0;
	    for (int i = 0; i < numberOfSearches; i++) {
		String ranndomString = generateRandomString();
		SimpleTimer readTimer = SimpleTimer.getInstance();
		if (wordFrequencies.get(ranndomString) != null) {
		    counter++;
		}
		readTimer.getDuration();
	    }
	    Map<Long, Long> readHistogram = SimpleTimer.histogram;
	    LnPMetrics readMetrics = new LnPMetrics(readHistogram);

	    System.out.println(readMetrics);
	    System.out.println("Total Number of hits: " + counter);
	    SimpleTimer.clearMap();

	} catch (FileNotFoundException ex) {
	    ex.printStackTrace();
	} catch (IOException ex) {
	    ex.printStackTrace();
	} finally {
	    try {
		reader.close();
		fis.close();
	    } catch (IOException ex) {
		ex.printStackTrace();
	    }
	}
    }

    /**
     * Below method is use for TreeMap performance testing.
     */
    private static void treeMapPerformanceTest() {

	//reading file line by line using BufferedReader       
	FileInputStream fis = null;
	BufferedReader reader = null;

	Map<String, Integer> wordFrequencies = new TreeMap<String, Integer>();

	try {
	    // we will load all the word frequency list in a TreeMap
	    fis = new FileInputStream(location);
	    reader = new BufferedReader(new InputStreamReader(fis));

	    System.out.println("############################################################");
	    System.out.println("Started TreeMap insertion performance test");

	    Runtime rt = Runtime.getRuntime();
	    long m0 = rt.totalMemory() - rt.freeMemory(); //used memory
	    String line = reader.readLine();
	    while (line != null && !line.isEmpty()) {
		// split the string on whitespace
		String[] splittedString = line.split("\\s+");
		String split1 = splittedString[0].toLowerCase().trim();
		Integer split2 = Integer.parseInt(splittedString[1].trim());
		SimpleTimer timer = SimpleTimer.getInstance();
		// now put it in TreeMap as key value  pair
		wordFrequencies.put(split1, split2);
		timer.getDuration();
		line = reader.readLine();
	    }
	    long m1 = rt.totalMemory() - rt.freeMemory();
	    Map<Long, Long> insertHistogram = SimpleTimer.histogram;
	    LnPMetrics insertionMetrics = new LnPMetrics(insertHistogram);
	    System.out.println(insertionMetrics);
	    System.out.println("Memory: Size in Memory after insertion (bytes): " + (m1 - m0));
	    System.out.println();
	    SimpleTimer.clearMap();

	    System.out.println("Started TreeMap Read performance test");
	    // now search a string
	    int counter = 0;
	    for (int i = 0; i < numberOfSearches; i++) {
		String ranndomString = generateRandomString();
		SimpleTimer readTimer = SimpleTimer.getInstance();
		if (wordFrequencies.get(ranndomString) != null) {
		    counter++;
		}
		readTimer.getDuration();
	    }
	    Map<Long, Long> readHistogram = SimpleTimer.histogram;
	    LnPMetrics readMetrics = new LnPMetrics(readHistogram);

	    System.out.println(readMetrics);
	    System.out.println("Total Number of hits: " + counter);
	    SimpleTimer.clearMap();

	} catch (FileNotFoundException ex) {
	    ex.printStackTrace();
	} catch (IOException ex) {
	    ex.printStackTrace();
	} finally {
	    try {
		reader.close();
		fis.close();
	    } catch (IOException ex) {
		ex.printStackTrace();
	    }
	}
    }

    /**
     * A simple method to generate random string for searches.
     * 
     * @return
     */
    public static String generateRandomString() {
	char[] text = new char[length];
	for (int i = 0; i < length; i++) {
	    text[i] = CHARACTERS.charAt(RANDOM.nextInt(CHARACTERS.length()));
	}
	return new String(text);
    }

    /**
     * A simple method to read the inputs.
     * 
     * @param args
     */
    private static void readInputs(String[] args) {

	if (args.length == 0) {
	    System.out.println("Please provide the inputs.");
	    System.exit(1);
	}

	try {
	    location = args[0];
	    numberOfStrings = Integer.parseInt(args[1]);
	    length = Integer.parseInt(args[2]);
	    numberOfSearches = Integer.parseInt(args[3]);
	} catch (Exception ex) {
	    System.out.println("Error occured while parsing the input passed. Using the default values.");
	}

    }

    /**
     * A simple method to generate random string to write into file
     * 
     * @return
     */
    public static String generateString() {
	StringBuilder builder = new StringBuilder();
	char[] text = new char[length];
	for (int i = 0; i < length; i++) {
	    text[i] = CHARACTERS.charAt(RANDOM.nextInt(CHARACTERS.length()));
	}
	builder.append(new String(text)).append(" ").append(RANDOM.nextInt(Integer.MAX_VALUE) + 1);
	return builder.toString();
    }
}
