README File

This file contains details about the Data Structure Project in the Advanced Data Structures course.

	Name: Ferhan Jamal
	Assignment: Implementation Project

Project Idea is - 
 
Establishing data-structures and their use-cases by evaluating various popular data-structures for handling string phrases in large files (cumulative frequency in the order of 3 billion or more) meaning some string phrases along with its frequencies in very large files.
 
Metrics being evaluated:
 
1) Memory requirements
2) Runtime for search, addition

Data Structures which I have used as part of this project is - 

1) HashMap
2) LinkedHashMap
3) TreeMap
4) Trie 

What I did as part of this project was - I am generating a text file which has around 10 million strings and its frequencies in the below format - 

	hello 100
	world 200
	abcde 300
	jamal 500

After that I am reading this file line by line and storing it in all the above data structures and measuring how much time it takes to insert the data in those data structures, how much time it takes to randomly lookup strings from those data structures and what is the size in memory after insertion.

So the program which I wrote is configurable and it accepts various parameters and "DataStructureProject" is my main class - 

1) Location: This is the location of file where you want to generate your text file which will have strings and its frequencies.
2) Number of String: This parameter means, how many strings you want to have in your file. In the above example it has only "4" words.
3) Length: This parameter means, what is the length of each string you want to have. In the above example, all the strings are of length "5".
4) Number of Searches: This parameter means, how many random searches you want to do on a particular data structure.

There are couple of ways to run this program. 

Running as Runnable Jar:-

If you are running it as a runnable jar from the command line, then use below command where the jar file is there -

	java -XX:-UseTLAB -jar dproject.jar C:/DataStructureProject/words.txt 10000 6 5000
	
What the above command will do is -  It will create the "words.txt" file in this folder for you "C:/DataStructureProject" automatically in which total number of strings will be "10000" and each string length will be "6". And total number of random searches you are planning to do is "5000" on various data structures.

If you want to generate a new file, then use this - 

	java -XX:-UseTLAB -jar dproject.jar C:/DataStructureProject/words1.txt 1000 6 500

Now what the above command will do is -  It will create a new "words1.txt" file in this folder for you "C:/DataStructureProject" automatically in which total number of strings will be "1000" and each string length will be "6". And total number of random searches you are planning to do is "500" on various data structures.

Running via Eclipse:-

Just import my project as it is in the eclipse. Now right click on the project and click Run Configurations for "DataStructureProject". And in the Program Arguments text box, type this - 

	C:/DataStructureProject/words.txt 10000 6 5000
	
It means exactly same as I have described above. And in the VM Arguments section, type this - 

	-XX:-UseTLAB	

NOTE: PLEASE SPECIFY THE INPUTS IN THE ORDER IT IS SHOWN ABOVE. 

After running the program, you will see output like this - 

	################################################
	Generating file with below parameters:
	File Location: C:/DataStructureProject/words.txt
	Number of Strings you want to generate: 5000000
	Length of each strings: 6
	Number of random Searches you want to do: 2000000
	################################################
	Created new file: C:/DataStructureProject/words.txt
	File has been generated. Please verify the file at the desired location.
	############################################################
	Started HashMap insertion performance test

	Total number of calls: 5000000
	Average Query Time: 0 ms
	95th percentile: 0 ms
	99th percentile: 0 ms
	Max query time: 1308 ms
	Minimum query time: 0 ms
	Total time: 2670 ms
	Memory: Size in Memory after insertion (bytes): 1251914328

	Started HashMap Read performance test

	Total number of calls: 2000000
	Average Query Time: 0 ms
	95th percentile: 0 ms
	99th percentile: 0 ms
	Max query time: 0 ms
	Minimum query time: 0 ms
	Total time: 0 ms
	Total Number of hits: 32248
	############################################################
	Started TreeMap insertion performance test

	Total number of calls: 5000000
	Average Query Time: 0 ms
	95th percentile: 0 ms
	99th percentile: 0 ms
	Max query time: 12 ms
	Minimum query time: 0 ms
	Total time: 46 ms
	Memory: Size in Memory after insertion (bytes): 261273144

	Started TreeMap Read performance test

	Total number of calls: 2000000
	Average Query Time: 0 ms
	95th percentile: 0 ms
	99th percentile: 0 ms
	Max query time: 65 ms
	Minimum query time: 0 ms
	Total time: 128 ms
	Total Number of hits: 31974
	############################################################
	Started LinkedHashMap insertion performance test

	Total number of calls: 5000000
	Average Query Time: 0 ms
	95th percentile: 0 ms
	99th percentile: 0 ms
	Max query time: 3445 ms
	Minimum query time: 0 ms
	Total time: 5761 ms
	Memory: Size in Memory after insertion (bytes): 1042494152

	Started LinkedHashMap Read performance test

	Total number of calls: 2000000
	Average Query Time: 0 ms
	95th percentile: 0 ms
	99th percentile: 0 ms
	Max query time: 2 ms
	Minimum query time: 0 ms
	Total time: 2 ms
	Total Number of hits: 31927

Above output should be self explanatory. But in short, it will tell you -

	Started HashMap insertion performance test

	Total number of calls: This is the number of calls we have made. Meaning these are number of entries which we have stored in the HashMap/LinkedHashMap/TreeMap/Trie
	Average Query Time: Average Time taken to insert into HashHMap
	95th percentile: 95th percentile to insert into HashMap
	99th percentile: 99th percentile to insert into HashMap
	Max query time: Maximum time taken to insert into HashMap
	Minimum query time: Minimum time taken to insert into HashMap
	Total time: Total time taken to insert into HashMap with all the strings and its frequencies.
	Memory: Size in Memory after insertion (bytes): This is the size in memory after inserting strings and its frequencies in the HashMap data structure

	Started HashMap Read performance test

	Total number of calls: This is the number of calls we have made. Meaning these are number of random searches which we have done on HashMap/LinkedHashMap/TreeMap/Trie after inserting.
	Average Query Time: Average Time taken to insert into HashHMap
	95th percentile: 95th percentile to insert into HashMap
	99th percentile: 99th percentile to insert into HashMap
	Max query time: Maximum time taken to insert into HashMap
	Minimum query time: Minimum time taken to insert into HashMap
	Total time: Total time taken to insert into HashMap with all the strings and its frequencies.
	Total Number of hits: This is the number of random hits we have encountered. Since we are randomly searching the strings in HashMap so if we found a string in the HashMap, we increment the count by 1. So this is the total number of hits we made randomly.
