README File

This file contains details about the Assignment 2 in the Advanced Data Structures course.

	Name: Ferhan Jamal
	Assignment: Assignment 2

After rigorous days of coding, I was able to modify "FractionalIteratedSearcher" class which has implementation of its constructor and find method. And I tested out both on correctness and performance aspects on question one and it works pretty good so far. "FractionalIteratedSearcher" has the main method which does correctness and performance test accordingly.. If you want you can tweak the performance parameters accordingly..

I was not able to implement "SplayTree" class as I was not able to understand SplayTree and its zig zag step properly :( . I tried a lot by reading from the wikipedia but somehow I was not able to clear my understanding properly on that..