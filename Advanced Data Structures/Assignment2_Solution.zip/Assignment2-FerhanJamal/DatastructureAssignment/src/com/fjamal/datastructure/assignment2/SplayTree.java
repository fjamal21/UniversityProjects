package com.fjamal.datastructure.assignment2;

import java.util.Comparator;


public class SplayTree<T extends Comparable<T>> 
extends BinarySearchTree<SplayTree.Node<T>,T> {

	protected static class Node<T> extends BinarySearchTree.BSTNode<Node<T>,T> {	}

	public SplayTree(Comparator<T> c) {
		super(new Node<T>(), c);
	}

	public SplayTree() {
		this(new DefaultComparator<T>());
	}

	/**
	 * Perform a splay operation on the node u
	 * @param u
	 */
	public void splay(Node<T> u) {
		// TODO: implement this
	}

	public boolean remove(T x) {
		// TODO: implement this
		// Look in the Sleator-Tarjan paper (available on the course web
		// page for how to implement this
		return false;
	}

	public void left_rotate(Node<T> u) {

	}

	public void right_rotate(Node<T> u) {

	}

	public boolean add(T x) {
		Node<T> u = newNode(x);
		if (!super.add(u)) return false;
		splay(u);
		return true;
	}

	public T find(T x) {
		Node<T> u = super.findLast(x);
		if (u != null) 
			splay(u);
		return u != null && u.x.equals(x) ? x : null;
	}

}
