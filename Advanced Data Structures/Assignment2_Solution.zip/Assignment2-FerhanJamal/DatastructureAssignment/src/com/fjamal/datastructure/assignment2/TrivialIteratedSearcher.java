package com.fjamal.datastructure.assignment2;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class TrivialIteratedSearcher<T extends Comparable<T>> 
		implements IteratedSearcher<T> {

	protected List<List<T>> lists;
	
	/**
	 * Constructor made from a list of sorted lists
	 * 
	 * @param lists - a list of sorted lists
	 */
	public TrivialIteratedSearcher(List<List<T>> lists) {
		// Just make a local copy of everything
		this.lists = new ArrayList<List<T>>();
		for (List<T> ell : lists) {
			this.lists.add(new ArrayList<T>(ell));
		}
	}
	
	public List<T> find(T x) {
		// TODO Auto-generated method stub
		List<T> results = new ArrayList<T>();
		for (List<T> ell : lists) {
			int i = Collections.binarySearch(ell, x);
			if (i < 0) i = -(i+1);
			results.add(i == ell.size() ? null : ell.get(i));
		}
		return results;
	}
	
	public static void main(String[] args) {
		// Some dumb test code
		System.out.print("Generating data ...");
		System.out.flush();
		long start = System.nanoTime();
		Random rand = new Random();
		int h = 20, n = 10;
		List<List<Integer>> lists = new ArrayList<List<Integer>>();
		int max = 0;
		for (int i = 0; i < h; i++) {
			List<Integer> ell = new ArrayList<Integer>();
			int x = 0;
			for (int j = 0; j < n; j++) {
				x += Integer.numberOfTrailingZeros(rand.nextInt())+1;
				ell.add(x);
			}
			if (x > max) max = x;
			lists.add(ell);
		}
		
		System.out.println(lists);
		long stop = System.nanoTime();
		System.out.println("done (" + (stop-start)*1e-9 + "s)");

		System.out.print("Building iterated searcher...");
		System.out.flush();
		start = System.nanoTime();
		IteratedSearcher<Integer> is 
			= new TrivialIteratedSearcher<Integer>(lists);
		System.out.println(is);
		stop = System.nanoTime();
		System.out.println("done (" + (stop-start)*1e-9 + "s)");

		System.out.print("Doing "+ n + " searches...");
		System.out.flush();
		start = System.nanoTime();
		for (int i = 0; i < n; i++) {
			int x = rand.nextInt(max+10);
			@SuppressWarnings("unused")
			List<Integer> result = is.find(x);
			System.out.println(result);
			/* if (i < 5) {
				System.out.print("" + x + " =>");
				for (Integer y : result) {
					System.out.print(" " + y);
				}
				System.out.println();
			} */
		}
		stop = System.nanoTime();
		System.out.println("done (" + (stop-start)*1e-9 + "s)");
		
	}

}
