package com.fjamal.datastructure.assignment2;

import java.util.List;

public interface IteratedSearcher<T extends Comparable<T>> {
	List<T> find(T x);

}
