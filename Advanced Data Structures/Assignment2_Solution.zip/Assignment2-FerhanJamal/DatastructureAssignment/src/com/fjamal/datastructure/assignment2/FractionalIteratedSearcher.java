package com.fjamal.datastructure.assignment2;

import java.util.*;

public class FractionalIteratedSearcher<T extends Comparable<T>> implements
		IteratedSearcher<T> {

	private class Element implements Comparable<Element> {
		T value;
		Element predecessor; // means predecessor of which element
		Element successor; // means successor of which element
		Element downPointer;
		int originalArray;

		public int compareTo(Element o) {
			if (o == null)
				return 1;
			return value.compareTo(o.value);
		}

		@Override
		public String toString() {
			String downPointerString;
			if (downPointer == null) {
				downPointerString = "_";
			} else {
				downPointerString = downPointer.value.toString();
			}
			String predecessorString;
			if (predecessor == null) {
				predecessorString = "_";
			} else {
				predecessorString = predecessor.value.toString();
			}
			String successorString;
			if (successor == null) {
				successorString = "_";
			} else {
				successorString = successor.value.toString();
			}
			return " " + value + " : [" + originalArray + ", "
					+ downPointerString + ", " + successorString + ", "
					+ predecessorString + "]";
		}
	}

	public List<List<Element>> ds;

	/**
	 * Constructor made from a list of sorted lists
	 * 
	 * @param lists
	 *            - a list of sorted lists
	 */
	public FractionalIteratedSearcher(List<List<T>> lists) {
		// A list of lists of type Element (that has pointers to original list,
		// down pointers and predecessor
		ds = new ArrayList<List<Element>>();

		// Book-keeping
		int sz = lists.size() - 1;

		// This stores the cascading that is pulled from a below level for
		// upwards level
		List<Element> previousCascadeUp = new ArrayList<Element>();

		// Loop from bottom to up and cascade
		for (int i = sz; i >= 0; i--) {
			List<T> oldList = lists.get(i);
			List<Element> newList = new ArrayList<Element>();
			List<Element> nextCascadeUp = new ArrayList<Element>();
			// Book-keeping
			int szOldList = oldList.size() - 1;
			boolean alternate = false;
			for (int j = 0; j <= szOldList; j++) {
				T t = oldList.get(j);
				Element e = new Element();
				e.value = t;
				e.originalArray = i;
				while (previousCascadeUp.size() > 0
						&& previousCascadeUp.get(0).value.compareTo(t) <= 0) {
					Element toAdd = previousCascadeUp.get(0);
					newList.add(toAdd);
					if (alternate) {
						nextCascadeUp.add(copy(toAdd));
						alternate = false;
					} else
						alternate = true;
					previousCascadeUp.remove(0);
				}
				newList.add(e);
				if (alternate) {
					nextCascadeUp.add(copy(e));
					alternate = false;
				} else {
					alternate = true;
				}
			}
			// If still some up-coming cascaded elements are left, merge them
			while (previousCascadeUp.size() > 0) {
				Element toAdd = previousCascadeUp.get(0);
				newList.add(toAdd);
				if (alternate) {
					nextCascadeUp.add(copy(toAdd));
					alternate = false;
				} else
					alternate = true;
				previousCascadeUp.remove(0);
			}
			// Set cascading for upwards level
			previousCascadeUp = nextCascadeUp;
			// Add current list to list of lists
			ds.add(0, newList);
		}

		for (int i = 0; i <= sz; i++) {
			Element successor = null;
			Stack<Element> followers = new Stack<Element>();
			for (int j = 0; j < ds.get(i).size(); j++) {
				if (ds.get(i).get(j).originalArray == i) {
					while (!followers.empty()) {
						Element e = followers.pop();
						e.predecessor = ds.get(i).get(j);
					}
					ds.get(i).get(j).successor = successor;
					successor = ds.get(i).get(j);
				} else {
					ds.get(i).get(j).successor = successor;
					followers.push(ds.get(i).get(j));
				}
			}
			while (!followers.empty()) {
				Element e = followers.pop();
				e.predecessor = null;
				e.successor = successor;
			}
		}

		for (int i = 0; i < sz; i++) {
			int curr = 0;
			if (ds.get(i).size() == 0)
				continue;
			for (int j = 0; j < ds.get(i + 1).size() && curr < ds.get(i).size(); j++) {
				if (ds.get(i + 1).get(j).compareTo(ds.get(i).get(curr)) < 0) {
				} else {
					while (curr < ds.get(i).size()
							&& ds.get(i + 1).get(j)
									.compareTo(ds.get(i).get(curr)) >= 0) {
						ds.get(i).get(curr).downPointer = ds.get(i + 1).get(j);
						curr++;
					}
				}
			}
		}
	}

	private Element copy(Element original) {
		if (original == null)
			return null;
		Element e = new Element();
		e.value = original.value;
		e.originalArray = original.originalArray;
		return e;
	}

	@SuppressWarnings("unchecked")
	public List<T> find(T x) {
		List<T> results = new ArrayList<T>();
		Element e = new Element();
		Element downNavigator = null;
		e.value = x;
		for (int i = 0; i < ds.size(); i++) {
			if (i == 0) {
				int index = Collections.binarySearch(ds.get(0), e);
				if (index < 0)
					index = -(index + 1);

				if (index == ds.get(i).size()) {
					results.add(null);
					downNavigator = null;
				} else {
					Element element = ds.get(i).get(index);
					if (element.originalArray == i) {
						// No need to check for successors, because we used
						// binary search -
						// and current element is from original array so are
						// already at best value
						results.add(element.value);
						downNavigator = element.downPointer;
					} else {
						if (element.successor != null
								&& element.successor.value.compareTo(x) >= 0) {
							// go for successor value (max hop should be 2,
							// because we do fractional cascade by k=2)
							while (element.successor != null
									&& element.successor.value.compareTo(x) >= 0)
								element = element.successor;
							results.add(element.value);
							downNavigator = element.downPointer;
						} else if (element.predecessor != null) {
							results.add(element.predecessor.value);
							downNavigator = element.predecessor.downPointer;
						} else {
							results.add(null);
							downNavigator = null;
						}
					}
				}
			} else {
				if (downNavigator == null) {
					if (ds.get(i).size() == 0) {
						// if current array is empty, ignore it. special case
						// handling
						// can happen only if last original array is empty, or
						// last original array has one element,
						// and second last is empty and so on
						results.add(null);
						downNavigator = null;
					} else {
						Element element = ds.get(i).get(ds.get(i).size() - 1);
						// go for successor value (max hop should be 2, because
						// we do fractional cascade by k=2)
						while (element.successor != null
								&& element.successor.value.compareTo(x) >= 0)
							element = element.successor;
						if (element.originalArray == i
								&& element.value.compareTo(x) >= 0) {
							results.add(element.value);
							downNavigator = element.downPointer;
						} else {
							results.add(null);
							downNavigator = null;
						}
					}
				} else {
					Element element = downNavigator;
					if (element.originalArray == i) {
						// go for successor value (max hop should be 2, because
						// we do fractional cascade by k=2)
						while (element.successor != null
								&& element.successor.value.compareTo(x) >= 0)
							element = element.successor;
						results.add(element.value);
						downNavigator = element.downPointer;
					} else {
						if (element.successor != null
								&& element.successor.value.compareTo(x) >= 0) {
							while (element.successor != null
									&& element.successor.value.compareTo(x) >= 0)
								element = element.successor;
							results.add(element.value);
							downNavigator = element.downPointer;
						} else if (element.predecessor != null) {
							results.add(element.predecessor.value);
							downNavigator = element.predecessor.downPointer;
						} else {
							results.add(null);
							downNavigator = null;
						}
					}
				}
			}
		}
		return results;
	}

	// main method
	public static void main(String[] args) {
		correctnessTest();
		performanceTest();
	}

	/**
	 * Below method is use for the performance test only
	 */
	private static void performanceTest() {
		// Some dumb test code
		System.out.println("############################################");
		System.out.println("STARING performance test");
		System.out.println("Generating data ...");
		System.out.println("Original Arrays ...");
		System.out.flush();
		long start = System.nanoTime();
		Random rand = new Random();
		int h = 1000, n = 10000;
		List<List<Integer>> lists = new ArrayList<List<Integer>>();
		int max = 0;
		for (int i = 0; i < h; i++) {
			List<Integer> ell = new ArrayList<Integer>();
			int x = 0;
			for (int j = 0; j < n; j++) {
				x += Integer.numberOfTrailingZeros(rand.nextInt()) + 1;
				ell.add(x);
			}
			if (x > max)
				max = x;
			System.out.println(ell);
			lists.add(ell);
		}
		long stop = System.nanoTime();
		System.out.println("done (" + (stop - start) * 1e-9 + "s)");

		System.out.print("Building iterated searcher...");
		System.out.flush();
		start = System.nanoTime();
		IteratedSearcher<Integer> is = new FractionalIteratedSearcher<Integer>(
				lists);
		stop = System.nanoTime();
		System.out.println("done (" + (stop - start) * 1e-9 + "s)");

		System.out
				.println("Fractional Cascaded Arrays in format of:: value : [values' original-array membership, down-pointer value, successor value, predecessor value] ...");
		System.out.println(((FractionalIteratedSearcher) is).ds.toString()
				.replaceAll("]],", "]],\n"));

		System.out.println("Doing " + n + " searches...");
		System.out.flush();
		start = System.nanoTime();
		for (int i = 0; i < n; i++) {
			int x = rand.nextInt(max + 10);
			if (i == 0)
				x = 1;
			@SuppressWarnings("unused")
			List<Integer> result = is.find(x);
			System.out.println(x + "\t:\t" + result);
		}
		stop = System.nanoTime();
		System.out.println("done (" + (stop - start) * 1e-9 + "s)");
		System.out.println("ENDED performance test");
		System.out.println("###################################################");

	}

	/**
	 * Below method is use just for correctness of the
	 * FractionalIteratedSearcher
	 */
	private static void correctnessTest() {
		// Some dumb test code
		System.out.println("##########################################");
		System.out.println("STARING correctness test");
		System.out.println("Generating data ...");
		System.out.println("Original Arrays ...");
		System.out.flush();
		long start = System.nanoTime();
		Random rand = new Random();
		int h = 4, n = 10;
		List<List<Integer>> lists = new ArrayList<List<Integer>>();
		int max = 0;
		for (int i = 0; i < h; i++) {
			List<Integer> ell = new ArrayList<Integer>();
			int x = 0;
			for (int j = 0; j < n; j++) {
				x += Integer.numberOfTrailingZeros(rand.nextInt()) + 1;
				ell.add(x);
			}
			if (x > max)
				max = x;
			System.out.println(ell);
			lists.add(ell);
		}
		long stop = System.nanoTime();
		System.out.println("done (" + (stop - start) * 1e-9 + "s)");

		System.out.print("Building iterated searcher...");
		System.out.flush();
		start = System.nanoTime();
		IteratedSearcher<Integer> is = new FractionalIteratedSearcher<Integer>(
				lists);
		stop = System.nanoTime();
		System.out.println("done (" + (stop - start) * 1e-9 + "s)");

		System.out
				.println("Fractional Cascaded Arrays in format of:: value : [values' original-array membership, down-pointer value, successor value, predecessor value] ...");
		System.out.println(((FractionalIteratedSearcher) is).ds.toString()
				.replaceAll("]],", "]],\n"));

		System.out.println("Doing " + n + " searches...");
		System.out.flush();
		start = System.nanoTime();
		for (int i = 0; i < n; i++) {
			int x = rand.nextInt(max + 10);
			if (i == 0)
				x = 1;
			@SuppressWarnings("unused")
			List<Integer> result = is.find(x);
			System.out.println(x + "\t:\t" + result);
		}
		stop = System.nanoTime();
		System.out.println("done (" + (stop - start) * 1e-9 + "s)");
		System.out.println("ENDED correctness test");
		System.out.println("###################################################");

	}
}
