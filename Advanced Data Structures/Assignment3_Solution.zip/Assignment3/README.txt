README File

This file contains details about the Assignment 3 in the Advanced Data Structures course.

	Name: Ferhan Jamal
	Assignment: Assignment 3

I was able to implement question 1 , question 2 and question 3 in this assignment. I have tested it out by adding a simple test class which is "PatriciaTrieTest.java". This class has correctness and performance test as well.
