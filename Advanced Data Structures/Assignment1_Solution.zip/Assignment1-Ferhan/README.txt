README File

This file contains details about the Assignment 1 in the Advanced Data Structures course.

	Name: Ferhan Jamal
	Assignment: Assignment 1

I have modified Treap class and PersistentTreap class basis on the question one and two. And for test purpose, I have implemented TreapCorrectnessTest class and TreapPerformanceTest class.

TreapCorrectnessTest -  This class contains the detail about the code which I have used to verify the changes I did in Treap and PersistentTreap class. I have modified these two classes as per question one and two. And TreapCorrectnessTest class contains the code which just verified whether all my changes is working fine or not. I have added some java docs in the code as well which will help us what is happening and what it is doing. If you run this class, you will see the output like this which I think is pretty clear enough to understand what is happening - 

	----------------------------------------
	STARTED::Treap Split Test
	Original Size: 10
	Original Treap elements:[0,1,7,8,9,11,13,14,15,19]
	After splitting on number 5: [7,8,9,11,13,14,15,19]
	Size after splitting: 8
	ENDED:: Treap Split Test
	----------------------------------------
	----------------------------------------
	STARTED:: Merge Test
	New Treap size: 4
	New Treap elements: [82,93,95,97]
	Status after merging: true
	Size after merging: 12
	Elements in Original Treap after merging: [7,8,9,11,13,14,15,19,82,93,95,97]
	ENDED:: Merge Test
	----------------------------------------
	----------------------------------------
	STARTED::Treap Rank Test
	11
	ENDED::Treap Rank Test
	----------------------------------------
	----------------------------------------
	STARTED::Sorted Array to Treap Test
	[0,1,4,9,16,25,36,49,64,81]
	ENDED::Sorted Array to Treap Test
	----------------------------------------
	----------------------------------------
	STARTED::Persistent Treap Test
	Inserting: 4 4 15 1 0 3 8 4 7 12 

	1 -> 3 -> 15 -> 15
	Removing: 15 true
	1 -> 3 -> 12 -> 15 -> 15

	null
	not found (this version has null root)
	null
	not found
	15
	1 -> 15
	15
	1 -> 15 -> 15
	15
	1 -> 15 -> 15
	15
	1 -> 3 -> 15 -> 15
	15
	1 -> 3 -> 15 -> 15
	15
	1 -> 3 -> 15 -> 15
	15
	1 -> 3 -> 12 -> 15 -> 15
	ENDED::Persistent to Treap Test
	----------------------------------------



TreapPerformanceTest -  This class contains the detail about the code which I have used for the performance test against my changes which I did in Treap and PersistentTreap class. I am using System.nanoTime() to measure the performance as compared to System.currentTimeMillis as nanoTime is significantly usually more accurate than currentTimeMillis.

I was able to insert around 50,000 elements in the treap within 83 ms. And I was able to perform 10,000 split operation within 129451 ms. And I created around new 10,000 elements in a new treap and I was able to pefrom merge operation within 17 ms and for the rank performance test, I was able to get the item back within 0 ms. :)  And then I was able to sort the array using the contructor of Treap within 24 ms. Below is the logs which will get printed out.

	----------------------------------------
	STARTED::Treap Split Performance Test
	Time it takes to insert elements in the treap: 93 ms
	Original Size: 49749
	Time it took to split: 129451 ms
	Size after splitting: 49546
	ENDED:: Treap Split Performance Test
	----------------------------------------
	----------------------------------------
	STARTED:: Merge Performance Test
	New Treap size: 9996
	Time take to merge: 17 ms
	Status after merging: false
	Size after merging: 49546
	ENDED:: Merge Performance Test
	----------------------------------------
	----------------------------------------
	STARTED::Treap Rank Performance Test
	Time it took to get the rank: 0
	Find Rank Item: 20554
	ENDED::Treap Rank Performance Test
	----------------------------------------
	----------------------------------------
	STARTED::Sorted Array to Treap Performance Test
	Time it took for sorted array to treap: 24 ms
	ENDED::Sorted Array to Treap Performance Test
	----------------------------------------
	----------------------------------------
	STARTED::Persistent Treap Performance Test
	Inserting: 13 5 1 6 6 7 3 17 12 11 

	5 -> 3 -> 1 -> 1
	Removing: 1 true
	5 -> 3 -> 1 -> 1

	null
	not found (this version has null root)
	null
	not found
	null
	not found
	1
	5 -> 1 -> 1
	1
	5 -> 1 -> 1
	1
	5 -> 1 -> 1
	null
	not found
	null
	not found
	null
	not found
	1
	5 -> 3 -> 1 -> 1
	ENDED::Persistent to Treap Performance Test
	----------------------------------------

As this is my first time submitting the assignment like this so not sure what else I am supposed to do apart from whatever I have done so far.. I will be learning a lot from this assignment after getting some feedback from the professor. It will be of great help if you can provide some suggestions and thoughts which I can improve on in the later assignments.